package com.crashingbug.travelapp

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

enum class TransitLine(val label: String) {
    CENTRAL("Central Line"),
    WESTERN("Western Line"),
    HARBOUR("Harbour Line"),
    METRO_1("Metro Line 1"),
    MONORAIL("Monorail"),
    NONE("None")
}

enum class Mode(val label: String, val emoji: String, val isRoad: Boolean, val waitMin: Int, val code: String) {
    BUS("Bus", "🚌", false, 5, "BS"),
    RAIL("Train", "🚆", false, 5, "RL"),
    MONO("Monorail", "🚝", false, 5, "MN"),
    METRO("Metro", "🚇", false, 4, "MT"),
    FERRY("Ferry", "⛴️", false, 10, "FR"),
    TAXI("Taxi", "🚕", true, 3, "TX"),
    RICKSHAW("Rickshaw", "🛺", true, 3, "RK"),
    CAB("Cab", "🚖", true, 6, "CB")
}

data class Leg(
    val from: String,
    val to: String,
    val mode: Mode,
    val minutes: Int,
    val fare: Int,
    val line: TransitLine = TransitLine.NONE,
    val isShared: Boolean = false,
    val driverFarePerSeat: Int = 0
)

data class Route(val legs: List<Leg>) {
    val totalMinutes: Int get() = legs.sumOf { it.minutes + it.mode.waitMin }
    val totalFare: Int get() = legs.sumOf { if (it.isShared && it.driverFarePerSeat > 0) it.driverFarePerSeat else it.fare }
    val emojis: String get() = legs.joinToString(" → ") { it.mode.emoji }
}

enum class Pref(val label: String) { SMART("Smart"), CHEAPEST("Cheapest"), FASTEST("Fastest") }

data class Ticket(
    val id: String,
    val leg: Leg,
    val info: String
)

data class DailyRoute(
    val from: String,
    val to: String,
    val pref: Pref,
    val roadShareMap: Map<Int, Boolean> = emptyMap(),
    val departureTime: String = "08:30 AM"
)

data class Segment(
    val from: String,
    val to: String,
    val mode: Mode,
    val minutes: Int,
    val fare: Int,
    val line: TransitLine = TransitLine.NONE
)

object Planner {
    private val rawNetwork = listOf(
        Segment("CSMT", "Masjid Bandar", Mode.RAIL, 3, 5, TransitLine.CENTRAL),
        Segment("Masjid Bandar", "Dadar", Mode.RAIL, 12, 5, TransitLine.CENTRAL),
        Segment("Dadar", "Kurla", Mode.RAIL, 10, 5, TransitLine.CENTRAL),
        Segment("Kurla", "Ghatkopar", Mode.RAIL, 5, 5, TransitLine.CENTRAL),
        Segment("Ghatkopar", "Bhandup", Mode.RAIL, 10, 5, TransitLine.CENTRAL),
        Segment("Bhandup", "Nahur", Mode.RAIL, 3, 5, TransitLine.CENTRAL),
        Segment("Nahur", "Mulund", Mode.RAIL, 3, 5, TransitLine.CENTRAL),
        Segment("Mulund", "Thane", Mode.RAIL, 5, 5, TransitLine.CENTRAL),

        Segment("Churchgate", "Dadar", Mode.RAIL, 18, 10, TransitLine.WESTERN),
        Segment("Dadar", "Andheri Station", Mode.RAIL, 20, 10, TransitLine.WESTERN),

        Segment("CSMT", "Masjid Bandar", Mode.RAIL, 10, 5, TransitLine.HARBOUR),
        Segment("Masjid Bandar", "Wadala", Mode.RAIL, 10, 5, TransitLine.HARBOUR),
        Segment("Wadala", "Kurla", Mode.RAIL, 8, 5, TransitLine.HARBOUR),
        Segment("Kurla", "Chembur", Mode.RAIL, 6, 5, TransitLine.HARBOUR),

        Segment("Andheri Station", "Ghatkopar", Mode.METRO, 22, 30, TransitLine.METRO_1),
        Segment("Wadala", "Chembur", Mode.MONO, 15, 20, TransitLine.MONORAIL),

        Segment("Andheri West", "Andheri Station", Mode.RICKSHAW, 10, 40),
        Segment("Andheri West", "Andheri Station", Mode.BUS, 15, 10),
        Segment("CSMT", "Gateway of India", Mode.BUS, 22, 10),
        Segment("CSMT", "Gateway of India", Mode.TAXI, 15, 110),
        Segment("CSMT", "Gateway of India", Mode.CAB, 15, 160),
        Segment("Churchgate", "Gateway of India", Mode.TAXI, 10, 100),
        Segment("Churchgate", "Gateway of India", Mode.BUS, 18, 10),
        Segment("Masjid Bandar", "Gateway of India", Mode.TAXI, 10, 90),
        Segment("Gateway of India", "Elephanta Caves", Mode.FERRY, 60, 230),
        Segment("Dadar", "Wadala", Mode.BUS, 12, 10),
        Segment("Chembur", "Ghatkopar", Mode.RICKSHAW, 18, 90),
        Segment("Andheri West", "Ghatkopar", Mode.CAB, 40, 380),
        Segment("Andheri West", "CSMT", Mode.CAB, 60, 620)
    )

    private val adjacencyMap: Map<String, List<Leg>> by lazy {
        val edges = mutableListOf<Leg>()
        for (s in rawNetwork) {
            edges.add(Leg(s.from, s.to, s.mode, s.minutes, s.fare, s.line))
            edges.add(Leg(s.to, s.from, s.mode, s.minutes, s.fare, s.line))
        }
        edges.groupBy { it.from }
    }

    val places: List<String> by lazy {
        adjacencyMap.keys.sorted()
    }

    private fun compressLegs(atomicLegs: List<Leg>): List<Leg> {
        if (atomicLegs.isEmpty()) return emptyList()
        val compressed = mutableListOf<Leg>()
        var current = atomicLegs.first()

        for (i in 1 until atomicLegs.size) {
            val next = atomicLegs[i]
            if (current.mode == next.mode && current.line == next.line && current.line != TransitLine.NONE) {
                current = current.copy(
                    to = next.to,
                    minutes = current.minutes + next.minutes,
                    fare = current.fare + next.fare
                )
            } else {
                compressed.add(current)
                current = next
            }
        }
        compressed.add(current)
        return compressed
    }

    fun plan(from: String, to: String, pref: Pref): List<Route> {
        if (from == to) return emptyList()
        val allRoutes = mutableListOf<Route>()

        fun traverse(current: String, visited: Set<String>, currentLegs: List<Leg>) {
            if (current == to) {
                allRoutes.add(Route(compressLegs(currentLegs)))
                return
            }
            if (currentLegs.size >= 8) return

            val nextOptions = adjacencyMap[current] ?: return
            for (edge in nextOptions) {
                if (edge.to !in visited) {
                    traverse(edge.to, visited + edge.to, currentLegs + edge)
                }
            }
        }

        traverse(from, setOf(from), emptyList())
        if (allRoutes.isEmpty()) return emptyList()

        val minTime = allRoutes.minOf { it.totalMinutes }.toDouble()
        val minFare = allRoutes.minOf { it.totalFare }.toDouble()
        fun score(r: Route) = r.totalMinutes / minTime + r.totalFare / minFare

        val pareto = mutableListOf<Route>()
        var bestFare = Int.MAX_VALUE
        for (r in allRoutes.sortedWith(compareBy({ it.totalMinutes }, { it.totalFare }))) {
            if (r.totalFare < bestFare) {
                pareto.add(r)
                bestFare = r.totalFare
            }
        }

        val rest = allRoutes.filter { it !in pareto }.sortedBy { score(it) }
        val picked = pareto + rest.take((8 - pareto.size).coerceAtLeast(0))

        return when (pref) {
            Pref.SMART -> picked.sortedBy { score(it) }
            Pref.CHEAPEST -> picked.sortedWith(compareBy({ it.totalFare }, { it.totalMinutes }))
            Pref.FASTEST -> picked.sortedWith(compareBy({ it.totalMinutes }, { it.totalFare }))
        }
    }
}

object Store {
    val tickets = mutableStateListOf<Ticket>()
    var daily by mutableStateOf<DailyRoute?>(null)
        private set

    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("travel", Context.MODE_PRIVATE)
        val from = prefs.getString("d_from", null)
        val to = prefs.getString("d_to", null)
        if (from != null && to != null) {
            val pref = runCatching { Pref.valueOf(prefs.getString("d_pref", "SMART")!!) }
                .getOrDefault(Pref.SMART)
            val time = prefs.getString("d_time", "08:30 AM") ?: "08:30 AM"
            daily = DailyRoute(from, to, pref, emptyMap(), time)
        }
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun saveDaily(d: DailyRoute) {
        daily = d
        prefs.edit()
            .putString("d_from", d.from)
            .putString("d_to", d.to)
            .putString("d_pref", d.pref.name)
            .putString("d_time", d.departureTime)
            .remove("d_last")
            .apply()
    }

    fun clearDaily() {
        daily = null
        prefs.edit().clear().apply()
    }

    fun autoBookIfDue(): Boolean {
        val d = daily ?: return false
        if (prefs.getString("d_last", "") == today()) return false
        val route = Planner.plan(d.from, d.to, d.pref).firstOrNull() ?: return false
        val updatedLegs = route.legs.mapIndexed { i, leg ->
            val shared = d.roadShareMap[i] ?: false
            leg.copy(isShared = shared)
        }
        bookRoute(Route(updatedLegs))
        prefs.edit().putString("d_last", today()).apply()
        return true
    }

    fun bookRoute(route: Route) {
        route.legs.forEach { leg ->
            tickets.add(makeTicket(leg))
        }
    }

    fun penalty(leg: Leg): Int = maxOf(10, (leg.fare * 0.2).roundToInt())

    private fun makeTicket(leg: Leg): Ticket {
        val id = "${leg.mode.code}-${Random.nextInt(1000, 9999)}"
        val lineInfo = if (leg.line != TransitLine.NONE) " (${leg.line.label})" else ""
        val info = if (!leg.mode.isRoad) {
            "Valid today · ${leg.from} to ${leg.to}$lineInfo · dummy ticket"
        } else {
            val shareInfo = if (leg.isShared) "Shared ride" else "Non-shared ride"
            val plate = "MH 0${Random.nextInt(1, 5)} ${('A'..'Z').random()}${('A'..'Z').random()} ${Random.nextInt(1000, 9999)}"
            "Booked ($shareInfo): ride to the end. Penalty ₹${penalty(leg)} if you quit.\nDriver plate: $plate · waiting at ${leg.from} (simulated)"
        }
        return Ticket(id, leg, info)
    }
}
