package com.crashingbug.travelapp.data.auth

import android.app.Activity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.crashingbug.travelapp.data.model.UserProfile
import com.google.firebase.FirebaseException
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.TimeUnit

sealed class AuthState {
    object SignedOut : AuthState()
    data class CodeSent(val verificationId: String) : AuthState()
    data class Authenticated(val userProfile: UserProfile) : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthViewModel : ViewModel() {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    var authState by mutableStateOf<AuthState>(AuthState.SignedOut)
        private set

    init {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            fetchUserProfile(currentUser.uid)
        }
    }

    fun sendVerificationCode(phoneNumber: String, activity: Activity) {
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    signInWithCredential(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    authState = AuthState.Error(e.localizedMessage ?: "Verification failed")
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    authState = AuthState.CodeSent(verificationId)
                }
            })
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifyCode(verificationId: String, code: String) {
        val credential = PhoneAuthProvider.getCredential(verificationId, code)
        signInWithCredential(credential)
    }

    private fun signInWithCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnSuccessListener { authResult ->
                val user = authResult.user
                if (user != null) {
                    fetchUserProfile(user.uid)
                }
            }
            .addOnFailureListener { e ->
                authState = AuthState.Error(e.localizedMessage ?: "Sign in failed")
            }
    }

    fun saveUserProfile(
        role: String,
        name: String,
        vehicleType: String = "",
        plate: String = ""
    ) {
        val uid = auth.currentUser?.uid ?: return
        val profile = UserProfile(
            uid = uid,
            role = role,
            name = name,
            vehicleType = vehicleType,
            plate = plate,
            updatedAt = Timestamp.now()
        )

        firestore.collection("users").document(uid)
            .set(profile)
            .addOnSuccessListener {
                authState = AuthState.Authenticated(profile)
            }
            .addOnFailureListener { e ->
                authState = AuthState.Error(e.localizedMessage ?: "Failed to save profile")
            }
    }

    private fun fetchUserProfile(uid: String) {
        firestore.collection("users").document(uid)
            .get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val profile = snapshot.toObject(UserProfile::class.java)
                    if (profile != null) {
                        authState = AuthState.Authenticated(profile)
                    }
                } else {
                    // Prompt profile creation with defaults
                    authState = AuthState.Error("Profile not set up yet")
                }
            }
            .addOnFailureListener { e ->
                authState = AuthState.Error(e.localizedMessage ?: "Error loading profile")
            }
    }

    fun signOut() {
        auth.signOut()
        authState = AuthState.SignedOut
    }
}