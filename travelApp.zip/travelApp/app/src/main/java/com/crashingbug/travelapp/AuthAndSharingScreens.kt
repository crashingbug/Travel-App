package com.crashingbug.travelapp

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.crashingbug.travelapp.data.auth.AuthManager
import com.crashingbug.travelapp.data.auth.UserProfile
import kotlin.random.Random

data class NearbyPassenger(
    val id: String,
    val name: String,
    val destination: String,
    val distanceMeters: Int,
    val mode: String
)

data class ChatMessage(
    val sender: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

object NearbySharingRepository {
    fun scanNearby(destination: String): List<NearbyPassenger> {
        val sampleNames = listOf("Rahul", "Priya", "Amit", "Neha", "Vikas", "Sneha")
        val modes = listOf("Rickshaw", "Taxi")
        val count = Random.nextInt(2, 5)
        return (1..count).map { i ->
            NearbyPassenger(
                id = "NP-$i",
                name = sampleNames.random(),
                destination = destination,
                distanceMeters = Random.nextInt(35, 195),
                mode = modes.random()
            )
        }
    }
}

@Composable
fun AuthScreen(onAuthenticated: () -> Unit) {
    var isSignUp by remember { mutableStateOf(false) }
    var phone by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("passenger") }
    var vehicleType by remember { mutableStateOf("Taxi") }
    var plate by remember { mutableStateOf("MH 01 AB 1234") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(if (isSignUp) "TravelApp Sign Up" else "TravelApp Login", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        if (isSignUp) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }

        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("Password / PIN") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))

        if (isSignUp) {
            Text("Select Role:", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = role == "passenger", onClick = { role = "passenger" }, label = { Text("Passenger") })
                FilterChip(selected = role == "driver", onClick = { role = "driver" }, label = { Text("Driver") })
            }
            Spacer(Modifier.height(8.dp))

            if (role == "driver") {
                OutlinedTextField(value = vehicleType, onValueChange = { vehicleType = it }, label = { Text("Vehicle Type (Taxi / Rickshaw / Cab)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = plate, onValueChange = { plate = it }, label = { Text("Vehicle Plate Number") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
            }
        }

        if (errorMsg != null) {
            Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(8.dp))
        }

        Button(onClick = {
            if (isSignUp) {
                val success = AuthManager.signUp(name, phone, pin, role, vehicleType, plate)
                if (success) onAuthenticated() else errorMsg = "Please fill all required fields"
            } else {
                val success = AuthManager.login(phone, pin)
                if (success) onAuthenticated() else errorMsg = "Invalid phone or password"
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text(if (isSignUp) "Sign Up" else "Login")
        }

        TextButton(onClick = { isSignUp = !isSignUp; errorMsg = null }) {
            Text(if (isSignUp) "Already have an account? Login" else "Don't have an account? Sign Up")
        }
    }
}

@Composable
fun ProfileScreen(user: UserProfile, onLogout: () -> Unit) {
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("👤 Profile", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Name: ${user.name}", style = MaterialTheme.typography.titleMedium)
                Text("Phone: ${user.phone}")
                Text("Role: ${user.role.replaceFirstChar { it.uppercase() }}")
                if (user.role == "driver") {
                    Text("Vehicle Type: ${user.vehicleType}")
                    Text("Plate Number: ${user.plate}")
                }
            }
        }
        val context = LocalContext.current
        OutlinedButton(onClick = {
            Toast.makeText(context, "Ad hub coming soon!", Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.fillMaxWidth()) {
            Text("📢 Ad Hub (Coming Soon)")
        }
        Button(onClick = {
            AuthManager.logout()
            onLogout()
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Logout")
        }
    }
}

@Composable
fun DriverHomeScreen(user: UserProfile) {
    var perSeatFare by remember { mutableStateOf("150") }
    var incomingRequests = remember { mutableStateListOf(
        mapOf("id" to "R-101", "passenger" to "Rohan", "from" to "Andheri Station", "to" to "Ghatkopar", "mode" to "Rickshaw"),
        mapOf("id" to "R-102", "passenger" to "Simran", "from" to "CSMT", "to" to "Gateway of India", "mode" to "Taxi")
    ) }

    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("🧑‍✈️ Driver Dashboard", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Driver: ${user.name} (${user.phone})", style = MaterialTheme.typography.titleMedium)
                Text("Vehicle: ${user.vehicleType} · Plate: ${user.plate}")
            }
        }

        OutlinedTextField(
            value = perSeatFare,
            onValueChange = { perSeatFare = it },
            label = { Text("Set Per-Seat Fare for Shared Rides (₹)") },
            modifier = Modifier.fillMaxWidth()
        )

        Text("Incoming Ride Requests (Simulated)", style = MaterialTheme.typography.titleMedium)
        if (incomingRequests.isEmpty()) {
            Text("No incoming ride requests at the moment.")
        } else {
            incomingRequests.forEach { req ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Passenger: ${req["passenger"]}", style = MaterialTheme.typography.titleSmall)
                        Text("Route: ${req["from"]} → ${req["to"]} (${req["mode"]})")
                        Text("Suggested per-seat fare: ₹$perSeatFare")
                        Button(onClick = {
                            incomingRequests.remove(req)
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text("Accept Request (Fare: ₹$perSeatFare)")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NearbySharingScreen(onBack: () -> Unit, onOpenChat: (String) -> Unit) {
    var destination by remember { mutableStateOf("Gateway of India") }
    var passengers by remember { mutableStateOf(NearbySharingRepository.scanNearby(destination)) }

    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("👥 Nearby Sharing Scan (~200m radius)", style = MaterialTheme.typography.headlineSmall)
        Text("Find passengers wanting to share a rickshaw or taxi to a similar destination.", style = MaterialTheme.typography.bodySmall)

        PlaceDropdown("Destination", destination, { destination = it; passengers = NearbySharingRepository.scanNearby(it) })

        if (passengers.isEmpty()) {
            Text("No passengers looking to share nearby.")
        } else {
            passengers.forEach { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.name} · ${p.mode}", style = MaterialTheme.typography.titleSmall)
                        Text("Destination: ${p.destination}")
                        Text("Distance: ~${p.distanceMeters}m away")
                        Button(onClick = { onOpenChat(p.name) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Open Temporary Chat")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TemporaryChatScreen(passengerName: String, onBack: () -> Unit) {
    val messages = remember { mutableStateListOf(
        ChatMessage("System", "Temporary chat opened with $passengerName. Messages auto-delete when ride starts or after 30 mins.")
    ) }
    var textInput by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = onBack) { Text("← Back") }
                Text("💬 Chat with $passengerName", style = MaterialTheme.typography.titleMedium)
            }
            Divider()
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                items(messages) { msg ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(8.dp)) {
                            Text("${msg.sender}:", style = MaterialTheme.typography.labelSmall)
                            Text(msg.text, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Type message...") },
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                if (textInput.isNotBlank()) {
                    messages.add(ChatMessage("You", textInput))
                    textInput = ""
                }
            }) {
                Text("Send")
            }
        }
    }
}
