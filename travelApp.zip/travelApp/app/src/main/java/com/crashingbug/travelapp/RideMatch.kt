package com.crashingbug.travelapp // change to match your project's package

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.QuerySnapshot
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

// ---------- Model ----------

data class Geo(val lat: Double = 0.0, val lng: Double = 0.0)
data class Spot(val name: String, val geo: Geo)

val spots = listOf(
    Spot("Masjid Bandar", Geo(18.9519, 72.8386)),
    Spot("CSMT", Geo(18.9398, 72.8355)),
    Spot("Gateway of India", Geo(18.9220, 72.8347)),
    Spot("Churchgate", Geo(18.9322, 72.8265)),
    Spot("Dadar", Geo(19.0178, 72.8478)),
    Spot("Andheri Station", Geo(19.1197, 72.8464)),
    Spot("Andheri West", Geo(19.1363, 72.8296))
)

fun spotByName(name: String) = spots.firstOrNull { it.name == name } ?: spots.first()

fun nearestSpotName(g: Geo): String {
    val s = spots.minByOrNull { distanceM(g, it.geo) }!!
    return if (distanceM(g, s.geo) <= 300) s.name else "My location"
}

const val BROADCAST_RADIUS_M = 1500.0
const val COMMIT_RADIUS_M = 300.0

enum class Vehicle(val emoji: String, val label: String) {
    TAXI("🚕", "Taxi"), RICKSHAW("🛺", "Rickshaw")
}

enum class RideMode(val label: String, val help: String) {
    COMMIT("Commit", "you can stop midway"),
    BOOK("Book", "ride all the way to the end")
}

enum class ReqStatus { OPEN, ACCEPTED, CANCELLED }

data class RideRequest(
    val id: String = "",
    val customerName: String = "",
    val vehicle: String = "TAXI",
    val pickupName: String = "",
    val pickupLat: Double = 0.0,
    val pickupLng: Double = 0.0,
    val dropName: String = "",
    val mode: String = "COMMIT",
    var status: String = "OPEN",
    var driverName: String = "",
    var plate: String = "",
    var driverLat: Double? = null,
    var driverLng: Double? = null
) {
    val pickup: Geo get() = Geo(pickupLat, pickupLng)
    val vehicleEnum: Vehicle get() = runCatching { Vehicle.valueOf(vehicle) }.getOrDefault(Vehicle.TAXI)
    val modeEnum: RideMode get() = runCatching { RideMode.valueOf(mode) }.getOrDefault(RideMode.COMMIT)
    val statusEnum: ReqStatus get() = runCatching { ReqStatus.valueOf(status) }.getOrDefault(ReqStatus.OPEN)
    val driverPos: Geo? get() = if (driverLat != null && driverLng != null) Geo(driverLat!!, driverLng!!) else null
}

data class OnlineDriver(
    val online: Boolean = false,
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val vehicleType: String = ""
)

object RideBoard {
    private val db = FirebaseFirestore.getInstance()
    val requests = mutableStateListOf<RideRequest>()
    val onlineDrivers = mutableStateListOf<OnlineDriver>()

    init {
        db.collection("requests")
            .addSnapshotListener { snapshot: QuerySnapshot?, e: FirebaseFirestoreException? ->
                if (e != null) return@addSnapshotListener
                if (snapshot != null) {
                    requests.clear()
                    for (doc in snapshot.documents) {
                        val r = doc.toObject(RideRequest::class.java)
                        if (r != null) requests.add(r)
                    }
                }
            }

        db.collection("driverStatus")
            .whereEqualTo("online", true)
            .addSnapshotListener { snapshot: QuerySnapshot?, e: FirebaseFirestoreException? ->
                if (e != null) return@addSnapshotListener
                if (snapshot != null) {
                    onlineDrivers.clear()
                    for (doc in snapshot.documents) {
                        val d = doc.toObject(OnlineDriver::class.java)
                        if (d != null) onlineDrivers.add(d)
                    }
                }
            }
    }

    fun broadcast(
        customer: String, vehicle: Vehicle, pickupName: String, pickup: Geo,
        dropName: String, mode: RideMode
    ): RideRequest {
         val id = "RQ-${Random.nextInt(1000, 9999)}"
        val r = RideRequest(
            id = id,
            customerName = customer,
            vehicle = vehicle.name,
            pickupName = pickupName,
            pickupLat = pickup.lat,
            pickupLng = pickup.lng,
            dropName = dropName,
            mode = mode.name,
            status = "OPEN"
        )
        db.collection("requests").document(id).set(r)
        return r
    }

    fun accept(r: RideRequest, driver: String, plate: String, pos: Geo) {
        db.collection("requests").document(r.id)
            .update(
                mapOf(
                    "status" to "ACCEPTED",
                    "driverName" to driver,
                    "plate" to plate,
                    "driverLat" to pos.lat,
                    "driverLng" to pos.lng
                )
            )
    }

    fun cancel(r: RideRequest) {
        db.collection("requests").document(r.id)
            .update("status", "CANCELLED")
    }
}

// ---------- Helpers ----------

fun distanceM(a: Geo, b: Geo): Double {
    val r = 6371000.0
    val dLat = Math.toRadians(b.lat - a.lat)
    val dLng = Math.toRadians(b.lng - a.lng)
    val h = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLng / 2).pow(2)
    return 2 * r * asin(sqrt(h))
}

fun fmtDist(m: Double) =
    if (m >= 1000) "%.1f km".format(m / 1000) else "${m.roundToInt()} m"

fun openMaps(ctx: Context, g: Geo, label: String) {
    val uri = Uri.parse("geo:${g.lat},${g.lng}?q=${g.lat},${g.lng}(${Uri.encode(label)})")
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No maps app found", Toast.LENGTH_SHORT).show()
    }
}

@SuppressLint("MissingPermission")
@Composable
fun rememberGps(enabled: Boolean): State<Geo?> {
    val ctx = LocalContext.current
    val loc = remember { mutableStateOf<Geo?>(null) }
    fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    var granted by remember {
        mutableStateOf(has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r.values.any { it }
    }
    LaunchedEffect(enabled) {
        if (enabled && !granted) {
            launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }
    DisposableEffect(enabled, granted) {
        if (!enabled || !granted) return@DisposableEffect onDispose { }
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val listener = object : LocationListener {
            override fun onLocationChanged(l: Location) { loc.value = Geo(l.latitude, l.longitude) }
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        val provider = if (has(Manifest.permission.ACCESS_FINE_LOCATION) && lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
            LocationManager.GPS_PROVIDER
        else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER
        else null
        try {
            if (provider != null) {
                lm.getLastKnownLocation(provider)?.let { loc.value = Geo(it.latitude, it.longitude) }
                lm.requestLocationUpdates(provider, 3000L, 5f, listener)
            }
        } catch (e: SecurityException) { }
        onDispose { lm.removeUpdates(listener) }
    }
    return loc
}

// ---------- Screen ----------

@Composable
fun RideMatchScreen(onBack: () -> Unit) {
    var role by rememberSaveable { mutableStateOf("customer") }
    var custName by rememberSaveable { mutableStateOf("Asha") }
    var drvName by rememberSaveable { mutableStateOf("Ramesh") }
    var plate by rememberSaveable { mutableStateOf("MH 01 AB 4521") }
    var drvVehicle by rememberSaveable { mutableStateOf(Vehicle.TAXI.name) }
    var currentId by rememberSaveable { mutableStateOf<String?>(null) }

    Column(
        Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("📣 Broadcast a ride", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = role == "customer", onClick = { role = "customer" }, label = { Text("🙋 Customer") })
            FilterChip(selected = role == "driver", onClick = { role = "driver" }, label = { Text("🧑‍✈️ Driver") })
        }
        if (role == "customer") {
            CustomerView(custName, { custName = it }, currentId, { currentId = it })
        } else {
            DriverView(drvName, { drvName = it }, plate, { plate = it }, drvVehicle, { drvVehicle = it })
        }
        Text(
            "This only helps drivers and customers meet. No fares are handled here. Real-time updates via Firebase Firestore.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun SpotDropdown(label: String, value: Spot, onChange: (Spot) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text("$label: ${value.name}") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            spots.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { onChange(s); open = false }) }
        }
    }
}

@Composable
private fun LocationRow(
    useGps: Boolean, onUseGps: (Boolean) -> Unit,
    simName: String, onSim: (String) -> Unit, gps: Geo?
) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Switch(checked = useGps, onCheckedChange = onUseGps)
        Text("Use real GPS")
    }
    if (useGps) {
        Text(
            if (gps == null) "Waiting for GPS fix… using the simulated spot until then."
            else "GPS: ${"%.4f".format(gps.lat)}, ${"%.4f".format(gps.lng)}",
            style = MaterialTheme.typography.bodySmall
        )
    }
    if (!useGps || gps == null) {
        SpotDropdown("I'm at (simulated)", spotByName(simName)) { onSim(it.name) }
    }
}

// ---------- Customer ----------

@Composable
private fun CustomerView(name: String, onName: (String) -> Unit, currentId: String?, onCurrent: (String?) -> Unit) {
    val ctx = LocalContext.current
    var useGps by rememberSaveable { mutableStateOf(false) }
    var simName by rememberSaveable { mutableStateOf("Masjid Bandar") }
    var dropName by rememberSaveable { mutableStateOf("Gateway of India") }
    var vehicle by rememberSaveable { mutableStateOf(Vehicle.TAXI.name) }
    var mode by rememberSaveable { mutableStateOf(RideMode.COMMIT.name) }
    val gps by rememberGps(useGps)
    val here = (if (useGps) gps else null) ?: spotByName(simName).geo

    val req = RideBoard.requests.firstOrNull { it.id == currentId }

    if (req == null || req.statusEnum == ReqStatus.CANCELLED) {
        OutlinedTextField(value = name, onValueChange = onName, label = { Text("Your name") }, modifier = Modifier.fillMaxWidth())
        LocationRow(useGps, { useGps = it }, simName, { simName = it }, gps)
        SpotDropdown("Going to", spotByName(dropName)) { dropName = it.name }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Vehicle.values().forEach { v ->
                FilterChip(selected = vehicle == v.name, onClick = { vehicle = v.name }, label = { Text("${v.emoji} ${v.label}") })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RideMode.values().forEach { m ->
                FilterChip(selected = mode == m.name, onClick = { mode = m.name }, label = { Text(m.label) })
            }
        }
        Text(
            "${RideMode.valueOf(mode).label}: ${RideMode.valueOf(mode).help}",
            style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = {
            val r = RideBoard.broadcast(
                name, Vehicle.valueOf(vehicle), nearestSpotName(here), here, dropName, RideMode.valueOf(mode)
            )
            onCurrent(r.id)
        }, modifier = Modifier.fillMaxWidth()) { Text("Broadcast to nearby drivers") }
        return
    }

    val alerted = RideBoard.onlineDrivers.count { distanceM(Geo(it.lat, it.lng), req.pickup) <= BROADCAST_RADIUS_M }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("${req.vehicleEnum.emoji} ${req.pickupName} → ${req.dropName}", style = MaterialTheme.typography.titleMedium)
            Text("${req.modeEnum.label}: ${req.modeEnum.help}", style = MaterialTheme.typography.bodySmall)
            if (req.statusEnum == ReqStatus.OPEN) {
                Text("📣 Broadcast sent. $alerted online drivers within ${fmtDist(BROADCAST_RADIUS_M)} were alerted.")
                Text("Only drivers at the pickup (within ${fmtDist(COMMIT_RADIUS_M)}) can commit. Waiting…")
            } else {
                val pos = req.driverPos
                Text("✅ ${req.driverName} committed", style = MaterialTheme.typography.titleSmall)
                Text("Number plate: ${req.plate}")
                if (pos != null) {
                    Text("Driver is ${fmtDist(distanceM(pos, here))} from you")
                    OutlinedButton(
                        onClick = { openMaps(ctx, pos, "${req.driverName} · ${req.plate}") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Open driver location in Maps") }
                }
            }
        }
    }
    if (req.statusEnum == ReqStatus.OPEN) {
        OutlinedButton(onClick = { RideBoard.cancel(req); onCurrent(null) }, modifier = Modifier.fillMaxWidth()) {
            Text("Cancel broadcast")
        }
    } else {
        Button(onClick = { onCurrent(null) }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
    }
}

// ---------- Driver ----------

@Composable
private fun DriverView(
    name: String, onName: (String) -> Unit,
    plate: String, onPlate: (String) -> Unit,
    vehicleName: String, onVehicle: (String) -> Unit
) {
    val ctx = LocalContext.current
    var useGps by rememberSaveable { mutableStateOf(false) }
    var simName by rememberSaveable { mutableStateOf("Masjid Bandar") }
    val gps by rememberGps(useGps)
    val here = (if (useGps) gps else null) ?: spotByName(simName).geo
    val vehicle = Vehicle.valueOf(vehicleName)

    OutlinedTextField(value = name, onValueChange = onName, label = { Text("Driver name") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(value = plate, onValueChange = onPlate, label = { Text("Number plate") }, modifier = Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Vehicle.values().forEach { v ->
            FilterChip(selected = vehicleName == v.name, onClick = { onVehicle(v.name) }, label = { Text("${v.emoji} ${v.label}") })
        }
    }
    LocationRow(useGps, { useGps = it }, simName, { simName = it }, gps)

    val mine = RideBoard.requests.filter {
        it.statusEnum == ReqStatus.ACCEPTED && it.plate == plate && it.driverName == name
    }
    mine.forEach { r ->
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("✅ You committed: ${r.customerName}", style = MaterialTheme.typography.titleSmall)
                Text("${r.pickupName} → ${r.dropName} · ${r.modeEnum.label} (${r.modeEnum.help})")
                OutlinedButton(
                    onClick = { openMaps(ctx, r.pickup, "Pickup: ${r.customerName}") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Open pickup in Maps") }
            }
        }
    }

    Text("Requests near you", style = MaterialTheme.typography.titleMedium)
    val nearby = RideBoard.requests.filter {
        it.statusEnum == ReqStatus.OPEN && it.vehicleEnum == vehicle && distanceM(here, rPickup(it)) <= BROADCAST_RADIUS_M
    }
    if (nearby.isEmpty()) {
        Text("No requests within ${fmtDist(BROADCAST_RADIUS_M)}.")
    }
    nearby.forEach { r ->
        val d = distanceM(here, r.pickup)
        val canCommit = d <= COMMIT_RADIUS_M
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("${r.customerName} · ${r.pickupName} → ${r.dropName}", style = MaterialTheme.typography.titleSmall)
                Text("${r.modeEnum.label}: ${r.modeEnum.help}")
                Text("Pickup is ${fmtDist(d)} from you")
                Button(
                    onClick = { RideBoard.accept(r, name, plate, here) },
                    enabled = canCommit,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Commit") }
                if (!canCommit) {
                    Text(
                        "You got the alert, but you need to be at the pickup (within ${fmtDist(COMMIT_RADIUS_M)}) to commit.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

private fun rPickup(r: RideRequest) = r.pickup
