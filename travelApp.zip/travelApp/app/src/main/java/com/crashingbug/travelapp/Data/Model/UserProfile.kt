package com.crashingbug.travelapp.data.model

import com.google.firebase.Timestamp

data class UserProfile(
    val uid: String = "",
    val role: String = "customer", // "customer" or "driver"
    val name: String = "",
    val vehicleType: String = "", // "taxi" or "rickshaw" (Drivers only)
    val plate: String = "",       // Driver plate (Drivers only)
    val fcmToken: String = "",
    val updatedAt: Timestamp = Timestamp.now()
)