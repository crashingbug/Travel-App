package com.crashingbug.travelapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private data class Feature(
    val key: String,
    val emoji: String,
    val title: String,
    val subtitle: String,
    val ready: Boolean
)

private val features = listOf(
    Feature("plan", "🗺️", "Plan a trip", "Multi-leg routes and booking", true),
    Feature("sharing", "👥", "Nearby sharing scan", "Find passengers within ~200m to share rickshaw/taxi", true),
    Feature("broadcast", "📣", "Broadcast a ride", "Alert nearby rickshaw and taxi drivers", true),
    Feature("meter", "🔍", "Meter check", "Compare the meter with GPS distance and time", true),
    Feature("timetables", "🕐", "Timetables", "Train, metro, mono and bus schedules", true),
    Feature("adhub", "📢", "Ad hub", "Promotions and local deals", false)
)

@Composable
fun HomeTab(onOpenPlan: () -> Unit, onOpenSharing: () -> Unit, subScreen: String?, onBackSub: () -> Unit, onOpenChat: (String) -> Unit) {
    if (subScreen == "sharing") {
        NearbySharingScreen(onBack = onBackSub, onOpenChat = onOpenChat)
        return
    }

    var screen by rememberSaveable { mutableStateOf("home") }

    when {
        screen == "home" -> HomeButtons(
            onOpen = { f ->
                when (f.key) {
                    "plan" -> onOpenPlan()
                    "sharing" -> onOpenSharing()
                    else -> screen = f.key
                }
            }
        )
        screen == "broadcast" -> RideMatchScreen(onBack = { screen = "home" })
        screen == "meter" -> MeterCheckScreen(onBack = { screen = "home" })
        screen == "timetables" -> TimetableMenu(
            onBack = { screen = "home" },
            onPick = { screen = "sched:${it.name}" }
        )
        screen.startsWith("sched:") -> ScheduleScreen(
            Mode.valueOf(screen.removePrefix("sched:")),
            onBack = { screen = "timetables" }
        )
        else -> ComingSoon(
            title = features.firstOrNull { it.key == screen }?.title ?: "Coming soon",
            onBack = { screen = "home" }
        )
    }
}

@Composable
private fun HomeButtons(onOpen: (Feature) -> Unit) {
    Column(
        Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("What do you want to do?", style = MaterialTheme.typography.headlineSmall)
        features.forEach { f ->
            val shape = RoundedCornerShape(8.dp)
            val mod = Modifier.fillMaxWidth().height(76.dp)
            val content: @Composable () -> Unit = {
                Column(horizontalAlignment = Alignment.Start, modifier = Modifier.fillMaxWidth()) {
                    Text("${f.emoji}  ${f.title}", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (f.ready) f.subtitle else "${f.subtitle} · Coming soon",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            if (f.ready) {
                Button(onClick = { onOpen(f) }, modifier = mod, shape = shape) { content() }
            } else {
                OutlinedButton(onClick = { onOpen(f) }, modifier = mod, shape = shape) { content() }
            }
        }
    }
}

@Composable
private fun TimetableMenu(onBack: () -> Unit, onPick: (Mode) -> Unit) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("Timetables", style = MaterialTheme.typography.headlineSmall)
        listOf(Mode.RAIL, Mode.MONO, Mode.METRO, Mode.BUS).forEach { m ->
            OutlinedButton(
                onClick = { onPick(m) },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(8.dp)
            ) { Text("${m.emoji} ${m.label} schedule") }
        }
    }
}

@Composable
private fun ComingSoon(title: String, onBack: () -> Unit) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Text("Coming soon.")
    }
}
