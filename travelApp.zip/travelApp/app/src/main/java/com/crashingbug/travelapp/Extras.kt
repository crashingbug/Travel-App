@file:OptIn(ExperimentalMaterial3Api::class)

package com.crashingbug.travelapp // change to match your project's package

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

// ---------- Dummy schedules ----------

private data class Timetable(val line: String, val times: List<String>)

private fun timetablesFor(mode: Mode): List<Timetable> = when (mode) {
    Mode.RAIL -> listOf(
        Timetable("Andheri → CSMT (slow)", listOf("05:40", "06:10", "06:40", "07:10", "07:40")),
        Timetable("Ghatkopar → CSMT", listOf("05:55", "06:15", "06:35", "06:55", "07:15")),
        Timetable("Dadar → Churchgate", listOf("06:00", "06:12", "06:24", "06:36", "06:48"))
    )
    Mode.MONO -> listOf(
        Timetable("Chembur → Wadala", listOf("06:00", "06:15", "06:30", "06:45", "07:00"))
    )
    Mode.METRO -> listOf(
        Timetable("Andheri → Ghatkopar (Line 1)", listOf("06:00", "06:08", "06:16", "06:24", "06:32"))
    )
    Mode.BUS -> listOf(
        Timetable("CSMT → Gateway of India", listOf("06:30", "06:50", "07:10", "07:30", "07:50")),
        Timetable("Andheri West → Andheri Station", listOf("06:00", "06:12", "06:24", "06:36", "06:48"))
    )
    else -> emptyList()
}

@Composable
fun ScheduleScreen(mode: Mode, onBack: () -> Unit) {
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("${mode.emoji} ${mode.label} schedule", style = MaterialTheme.typography.headlineSmall)
        Text("Dummy data, not real timings.", style = MaterialTheme.typography.bodySmall)
        timetablesFor(mode).forEach { t ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(t.line, style = MaterialTheme.typography.titleSmall)
                    Text(t.times.joinToString("  ·  "))
                }
            }
        }
    }
}

// ---------- Meter Check ----------

@SuppressLint("MissingPermission")
@Composable
fun MeterCheckScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var isTracking by rememberSaveable { mutableStateOf(false) }
    var isNightTime by rememberSaveable { mutableStateOf(false) }
    var distanceKm by remember { mutableStateOf(0.0) }
    var waitingMinutes by remember { mutableStateOf(0.0) }
    var statusText by remember { mutableStateOf("Ready to start") }

    // Manual test mode toggle for testing without GPS movement
    var manualMode by rememberSaveable { mutableStateOf(false) }
    var manualKm by remember { mutableStateOf(5.0) }
    var manualWaitMin by remember { mutableStateOf(2.0) }

    val effectiveKm = if (manualMode) manualKm else distanceKm
    val effectiveWait = if (manualMode) manualWaitMin else waitingMinutes

    // Mumbai Auto and Taxi Fare formulas provided by user
    val autoFare = (Math.round(((23.0 + (Math.max(0.0, effectiveKm - 1.5) * 15.33)) + (Math.max(0.0, effectiveWait) * 1.50)) * (if (isNightTime) 1.25 else 1.0))).toInt()
    val taxiFare = (Math.round(((28.0 + (Math.max(0.0, effectiveKm - 1.5) * 18.66)) + (Math.max(0.0, effectiveWait) * 1.86)) * (if (isNightTime) 1.25 else 1.0))).toInt()

    // GPS tracking for moving vs waiting
    DisposableEffect(isTracking) {
        if (!isTracking) return@DisposableEffect onDispose {}

        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var lastLocation: Location? = null
        var lastTime = System.currentTimeMillis()

        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                val currentTime = System.currentTimeMillis()
                val deltaSec = (currentTime - lastTime) / 1000.0
                lastTime = currentTime

                val prev = lastLocation
                if (prev != null) {
                    val distM = prev.distanceTo(loc).toDouble()
                    distanceKm += distM / 1000.0

                    // Speed check: if speed < 0.5 m/s or distance moved < 2 meters in interval, accumulate waiting time
                    val speed = if (deltaSec > 0) distM / deltaSec else 0.0
                    if (speed < 0.5) {
                        waitingMinutes += deltaSec / 60.0
                        statusText = "Waiting / Stopped"
                    } else {
                        statusText = "Moving (%.1f km/h)".format(speed * 3.6)
                    }
                } else {
                    statusText = "GPS fix acquired. Tracking..."
                }
                lastLocation = loc
            }
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }

        val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER
        else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER
        else null

        try {
            if (provider != null) {
                lm.getLastKnownLocation(provider)?.let { lastLocation = it }
                lm.requestLocationUpdates(provider, 2000L, 2f, listener)
                statusText = "Acquiring GPS..."
            } else {
                statusText = "GPS disabled. Enable location or use Manual Mode."
            }
        } catch (_: SecurityException) {
            statusText = "Location permission denied."
        }

        onDispose {
            try {
                lm.removeUpdates(listener)
            } catch (_: Exception) {}
        }
    }

    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("🔍 Meter Check", style = MaterialTheme.typography.headlineSmall)
        Text("Compare auto and taxi meters with GPS distance and waiting time.", style = MaterialTheme.typography.bodySmall)

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = isNightTime, onCheckedChange = { isNightTime = it })
            Text("Night Time (12 AM - 5 AM · 1.25x)")
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = manualMode, onCheckedChange = { manualMode = it })
            Text("Manual Test Mode (bypass GPS)")
        }

        if (!manualMode) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("GPS Status: $statusText", style = MaterialTheme.typography.titleSmall)
                    Text("Distance: %.2f km".format(distanceKm))
                    Text("Waiting Time: %.1f min".format(waitingMinutes))

                    if (!isTracking) {
                        Button(
                            onClick = {
                                distanceKm = 0.0
                                waitingMinutes = 0.0
                                isTracking = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Start GPS Meter")
                        }
                    } else {
                        OutlinedButton(
                            onClick = { isTracking = false; statusText = "Stopped" },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Stop GPS Meter")
                        }
                    }
                }
            }
        } else {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Manual Parameters", style = MaterialTheme.typography.titleSmall)
                    Text("Distance: %.1f km".format(manualKm))
                    Slider(
                        value = manualKm.toFloat(),
                        onValueChange = { manualKm = it.toDouble() },
                        valueRange = 0.5f..30f
                    )
                    Text("Waiting Time: %.0f min".format(manualWaitMin))
                    Slider(
                        value = manualWaitMin.toFloat(),
                        onValueChange = { manualWaitMin = it.toDouble() },
                        valueRange = 0f..60f
                    )
                }
            }
        }

        // Fare Calculation Results
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Calculated Fares (Mumbai)", style = MaterialTheme.typography.titleMedium)
                Text("🛺 Auto Fare: ₹$autoFare", style = MaterialTheme.typography.titleLarge)
                Text("🚕 Taxi Fare: ₹$taxiFare", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Formula includes base fare (₹23 auto / ₹28 taxi for first 1.5 km), distance rate (₹15.33/km auto / ₹18.66/km taxi), waiting charge (₹1.50/min auto / ₹1.86/min taxi), and night multiplier (1.25x if enabled).",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

// ---------- More tab ----------

@Composable
fun MoreTab() {
    var screen by rememberSaveable { mutableStateOf("home") }
    when (screen) {
        "home" -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Schedules", style = MaterialTheme.typography.headlineSmall)
            listOf(Mode.RAIL, Mode.MONO, Mode.METRO, Mode.BUS).forEach { m ->
                OutlinedButton(onClick = { screen = m.name }, modifier = Modifier.fillMaxWidth()) {
                    Text("${m.emoji} ${m.label} schedule")
                }
            }
        }
        else -> ScheduleScreen(Mode.valueOf(screen), onBack = { screen = "home" })
    }
}
