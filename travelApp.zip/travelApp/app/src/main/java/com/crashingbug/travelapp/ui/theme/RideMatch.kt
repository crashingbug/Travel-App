package com.crashingbug.travelapp.ui

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.crashingbug.travelapp.data.auth.AuthState
import com.crashingbug.travelapp.data.auth.AuthViewModel

@Composable
fun RideMatchScreen(
    authViewModel: AuthViewModel = viewModel()
) {
    val authState = authViewModel.authState
    val context = LocalContext.current
    val activity = context as? Activity

    var showProfileDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // --- Top Bar / Auth Header ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (authState) {
                    is AuthState.Authenticated -> {
                        val profile = authState.userProfile
                        Column {
                            Text(
                                text = "Logged in as: ${profile.name}",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Role: ${profile.role.replaceFirstChar { it.uppercase() }}" +
                                        if (profile.role == "driver") " (${profile.vehicleType.uppercase()} - ${profile.plate})" else "",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Button(onClick = { authViewModel.signOut() }) {
                            Text("Sign Out")
                        }
                    }
                    else -> {
                        Text(
                            text = "Not Signed In",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Button(onClick = { showProfileDialog = true }) {
                            Text("Sign In / Setup")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Existing Ride Match UI goes here (Ride Board, Request Ride Form, etc.)
    }

    // --- Authentication & Profile Setup Dialog ---
    if (showProfileDialog) {
        PhoneAuthDialog(
            authViewModel = authViewModel,
            activity = activity,
            onDismiss = { showProfileDialog = false }
        )
    }
}

@Composable
fun PhoneAuthDialog(
    authViewModel: AuthViewModel,
    activity: Activity?,
    onDismiss: () -> Unit
) {
    var phoneNumber by remember { mutableStateOf("+91") }
    var otpCode by remember { mutableStateOf("") }

    // Default prefilled form state
    var selectedRole by remember { mutableStateOf("customer") } // "customer" or "driver"
    var name by remember { mutableStateOf("Aarav Mehta") }
    var vehicleType by remember { mutableStateOf("taxi") }
    var plate by remember { mutableStateOf("MH-01-AB-1234") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sign In & Setup Profile") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                when (val state = authViewModel.authState) {
                    is AuthState.SignedOut, is AuthState.Error -> {
                        if (state is AuthState.Error) {
                            Text(text = state.message, color = MaterialTheme.colorScheme.error)
                        }
                        OutlinedTextField(
                            value = phoneNumber,
                            onValueChange = { phoneNumber = it },
                            label = { Text("Phone Number") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                if (activity != null) {
                                    authViewModel.sendVerificationCode(phoneNumber, activity)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Send OTP")
                        }
                    }

                    is AuthState.CodeSent -> {
                        OutlinedTextField(
                            value = otpCode,
                            onValueChange = { otpCode = it },
                            label = { Text("6-Digit OTP") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                authViewModel.verifyCode(state.verificationId, otpCode)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Verify Code")
                        }
                    }

                    is AuthState.Authenticated -> {
                        Text("Configure Profile Details:")

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedRole == "customer",
                                onClick = {
                                    selectedRole = "customer"
                                    name = "Aarav Mehta"
                                }
                            )
                            Text("Customer")
                            Spacer(modifier = Modifier.width(16.dp))
                            RadioButton(
                                selected = selectedRole == "driver",
                                onClick = {
                                    selectedRole = "driver"
                                    name = "Rajesh Kumar"
                                }
                            )
                            Text("Driver")
                        }

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Name") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (selectedRole == "driver") {
                            OutlinedTextField(
                                value = vehicleType,
                                onValueChange = { vehicleType = it },
                                label = { Text("Vehicle Type (taxi / rickshaw)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = plate,
                                onValueChange = { plate = it },
                                label = { Text("Number Plate") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Button(
                            onClick = {
                                authViewModel.saveUserProfile(
                                    role = selectedRole,
                                    name = name,
                                    vehicleType = if (selectedRole == "driver") vehicleType else "",
                                    plate = if (selectedRole == "driver") plate else ""
                                )
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Profile")
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}