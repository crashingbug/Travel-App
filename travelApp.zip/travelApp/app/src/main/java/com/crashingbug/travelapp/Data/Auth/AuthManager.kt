package com.crashingbug.travelapp.data.auth

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class UserProfile(
    val name: String = "",
    val phone: String = "",
    val role: String = "passenger", // "passenger" or "driver"
    val vehicleType: String = "Taxi", // For driver
    val plate: String = "MH 01 AB 1234" // For driver
)

object AuthManager {
    private lateinit var prefs: SharedPreferences

    var currentUser by mutableStateOf<UserProfile?>(null)
        private set

    fun init(context: Context) {
        prefs = context.getSharedPreferences("auth_store", Context.MODE_PRIVATE)
        loadCurrent()
    }

    private fun loadCurrent() {
        val phone = prefs.getString("current_phone", null)
        if (phone != null) {
            val name = prefs.getString("u_${phone}_name", "") ?: ""
            val role = prefs.getString("u_${phone}_role", "passenger") ?: "passenger"
            val vehicle = prefs.getString("u_${phone}_vehicle", "Taxi") ?: "Taxi"
            val plate = prefs.getString("u_${phone}_plate", "MH 01 AB 1234") ?: "MH 01 AB 1234"
            currentUser = UserProfile(name, phone, role, vehicle, plate)
        } else {
            currentUser = null
        }
    }

    fun signUp(name: String, phone: String, pin: String, role: String, vehicleType: String, plate: String): Boolean {
        if (phone.isBlank() || name.isBlank() || pin.isBlank()) return false
        prefs.edit()
            .putString("u_${phone}_name", name)
            .putString("u_${phone}_role", role)
            .putString("u_${phone}_pin", pin)
            .putString("u_${phone}_vehicle", vehicleType)
            .putString("u_${phone}_plate", plate)
            .putString("current_phone", phone)
            .apply()
        loadCurrent()
        return true
    }

    fun login(phone: String, pin: String): Boolean {
        val savedPin = prefs.getString("u_${phone}_pin", null)
        if (savedPin == pin) {
            prefs.edit().putString("current_phone", phone).apply()
            loadCurrent()
            return true
        }
        return false
    }

    fun logout() {
        prefs.edit().remove("current_phone").apply()
        currentUser = null
    }
}
