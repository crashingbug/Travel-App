package com.crashingbug.travelapp
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.crashingbug.travelapp.data.auth.AuthManager
import com.crashingbug.travelapp.data.auth.UserProfile


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AuthManager.init(applicationContext)
        Store.init(applicationContext)
        val autoBooked = Store.autoBookIfDue()
        setContent {
            MaterialTheme {
                val user = AuthManager.currentUser
                if (user == null) {
                    AuthScreen(onAuthenticated = { })
                } else if (user.role == "driver") {
                    DriverApp(user)
                } else {
                    PassengerApp(autoBooked)
                }
            }
        }
    }
}



@Composable
fun PassengerApp(autoBooked: Boolean) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var activeSubScreen by rememberSaveable { mutableStateOf<String?>(null) }
    var chatPassenger by remember { mutableStateOf<String?>(null) }

    if (chatPassenger != null) {
        TemporaryChatScreen(passengerName = chatPassenger!!) { chatPassenger = null }
        return
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0; activeSubScreen = null }, icon = { Text("🏠") }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1; activeSubScreen = null }, icon = { Text("🗺️") }, label = { Text("Plan") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2; activeSubScreen = null }, icon = { Text("🎫") }, label = { Text("Tickets (${Store.tickets.size})") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3; activeSubScreen = null }, icon = { Text("🔁") }, label = { Text("Daily") })
                NavigationBarItem(selected = tab == 4, onClick = { tab = 4; activeSubScreen = null }, icon = { Text("👤") }, label = { Text("Profile") })
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab(
                    onOpenPlan = { tab = 1 },
                    onOpenSharing = { activeSubScreen = "sharing" },
                    subScreen = activeSubScreen,
                    onBackSub = { activeSubScreen = null },
                    onOpenChat = { chatPassenger = it }
                )
                1 -> PlanTab(onBooked = { tab = 2 })
                2 -> TicketsTab()
                3 -> DailyTab(autoBooked)
                else -> ProfileScreen(AuthManager.currentUser ?: UserProfile(), onLogout = {})
            }
        }
    }
}

@Composable
fun PlaceDropdown(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: $value")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Planner.places.forEach { p ->
                DropdownMenuItem(text = { Text(p) }, onClick = { onChange(p); open = false })
            }
        }
    }
}

@Composable
fun PlanTab(onBooked: () -> Unit) {
    var from by rememberSaveable { mutableStateOf("Andheri West") }
    var to by rememberSaveable { mutableStateOf("Elephanta Caves") }
    var pref by rememberSaveable { mutableStateOf(Pref.SMART) }
    var routes by remember { mutableStateOf(Planner.plan("Andheri West", "Elephanta Caves", Pref.SMART)) }
    var selected by remember { mutableStateOf<Route?>(null) }

    fun refresh() { routes = Planner.plan(from, to, pref) }

    val sel = selected
    if (sel != null) {
        RouteDetail(sel, pref, from, to, onBack = { selected = null }, onBooked = {
            selected = null
            onBooked()
        })
        return
    }

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Plan a trip", style = MaterialTheme.typography.headlineSmall)
        PlaceDropdown("From", from, { from = it; refresh() })
        PlaceDropdown("To", to, { to = it; refresh() })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pref.values().forEach { p ->
                FilterChip(selected = pref == p, onClick = { pref = p; refresh() }, label = { Text(p.label) })
            }
        }
        if (routes.isEmpty()) {
            Text("No routes found. Pick two different places.")
        } else {
            val cheapest = routes.minByOrNull { it.totalFare }
            val fastest = routes.minByOrNull { it.totalMinutes }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(routes) { r ->
                    val tags = buildList {
                        if (r == routes.first()) add("Recommended")
                        if (r == cheapest) add("Cheapest")
                        if (r == fastest) add("Fastest")
                    }
                    Card(Modifier.fillMaxWidth().clickable { selected = r }) {
                        Column(Modifier.padding(12.dp)) {
                            if (tags.isNotEmpty()) Text(tags.joinToString(" · "), style = MaterialTheme.typography.labelMedium)
                            Text(r.emojis, style = MaterialTheme.typography.titleMedium)
                            Text("${r.totalMinutes} min · ₹${r.totalFare}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RouteDetail(route: Route, pref: Pref, from: String, to: String, onBack: () -> Unit, onBooked: () -> Unit) {
    val ctx = LocalContext.current
    val shareChoices = remember { mutableStateMapOf<Int, Boolean>() } // leg index -> isShared

    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("$from → $to", style = MaterialTheme.typography.headlineSmall)
        Text("${route.totalMinutes} min · ₹${route.totalFare}")
        route.legs.forEachIndexed { i, leg ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${leg.mode.emoji} ${leg.mode.label}: ${leg.from} → ${leg.to}", style = MaterialTheme.typography.titleSmall)
                    Text("${leg.minutes} min · ₹${leg.fare}")
                    if (leg.mode.isRoad) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = shareChoices[i] != true, onClick = { shareChoices[i] = false }, label = { Text("Non-share") })
                            FilterChip(selected = shareChoices[i] == true, onClick = { shareChoices[i] = true }, label = { Text("Share") })
                        }
                        Text(
                            if (shareChoices[i] == true) "Shared road leg: split fare, booked with penalty ₹${Store.penalty(leg)} if quit"
                            else "Non-shared road leg: booked with penalty ₹${Store.penalty(leg)} if quit",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
        Button(onClick = {
            val updatedLegs = route.legs.mapIndexed { i, leg ->
                leg.copy(isShared = shareChoices[i] == true)
            }
            Store.bookRoute(Route(updatedLegs))
            onBooked()
        }, modifier = Modifier.fillMaxWidth()) { Text("Book whole trip (dummy tickets)") }

        var departureTime by remember { mutableStateOf("08:30 AM") }
        OutlinedTextField(value = departureTime, onValueChange = { departureTime = it }, label = { Text("Departure Time (e.g. 08:30 AM)") }, modifier = Modifier.fillMaxWidth())

        OutlinedButton(onClick = {
            val roadShareMap = route.legs.indices.associateWith { shareChoices[it] == true }
            Store.saveDaily(DailyRoute(from, to, pref, roadShareMap, departureTime))
            Toast.makeText(ctx, "Saved as daily route at $departureTime", Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.fillMaxWidth()) { Text("Set as my daily route") }
    }
}

@Composable
fun TicketsTab() {
    val ctx = LocalContext.current
    if (Store.tickets.isEmpty()) {
        Text("No tickets yet. Book a trip from the Plan tab.", Modifier.padding(16.dp))
        return
    }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Store.tickets.toList()) { t ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${t.leg.mode.emoji} ${t.leg.mode.label} · ${t.id}", style = MaterialTheme.typography.titleSmall)
                    Text("${t.leg.from} → ${t.leg.to} · ₹${t.leg.fare}")
                    Text(t.info, style = MaterialTheme.typography.bodySmall)
                    if (t.leg.mode.isRoad) {
                        TextButton(onClick = {
                            Store.tickets.remove(t)
                            Toast.makeText(ctx, "Left booked ride: penalty ₹${Store.penalty(t.leg)} (dummy)", Toast.LENGTH_LONG).show()
                        }) { Text("Leave ride") }
                    }
                }
            }
        }
    }
}

@Composable
fun DailyTab(autoBooked: Boolean) {
    val d = Store.daily
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Daily route", style = MaterialTheme.typography.headlineSmall)
        if (d == null) {
            Text("None set. Open a route in the Plan tab and tap \"Set as my daily route\".")
        } else {
            Text("${d.from} → ${d.to}")
            Text("Departure Time: ${d.departureTime}")
            Text("Preference: ${d.pref.label}")
            Text("Tickets are booked automatically (dummy) at ${d.departureTime} each day.")
            if (autoBooked) Text("Today's tickets were auto-booked. Check the Tickets tab.")
            OutlinedButton(onClick = { Store.clearDaily() }) { Text("Remove daily route") }
        }
    }
}
