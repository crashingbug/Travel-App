package com.crashingbug.travelapp

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.crashingbug.travelapp.data.auth.UserProfile

// Driver-only UI. Passengers never see this; MainActivity only opens it for driver accounts.
@Composable
fun DriverApp(user: UserProfile) {
    var tab by rememberSaveable { mutableStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("🧑‍✈️") }, label = { Text("Driver Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("👤") }, label = { Text("Profile") })
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (tab == 0) DriverHomeScreen(user)
            else ProfileScreen(user, onLogout = {})
        }
    }
}
